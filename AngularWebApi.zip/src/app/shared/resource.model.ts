export class Resource {
}
