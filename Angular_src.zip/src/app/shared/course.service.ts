import { Injectable } from '@angular/core';
import { Course } from './course.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
 

  formData: Course = new Course;
  readonly rootURL="https://localhost:44367/api/Course";

  constructor(private http:HttpClient) { }

  postCourse(formData:Course)
  {
    return this.http.post(this.rootURL+'/InsertCourse',formData);
  }
}
