import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ResourceesComponent } from './resourcees/resourcees.component';
import { ResourceComponent } from './resourcees/resource/resource.component';
import { ResourceListComponent } from './resourcees/resource-list/resource-list.component';
import { ResourceService } from './shared/resource.service';
import { CourseService } from './shared/course.service';
import { CourseComponent } from './courses/course/course.component';

import { CoursesComponent } from './courses/courses.component';
import { CourseListComponent } from './courses/course-list/course-list.component';

@NgModule({
  declarations: [
    AppComponent,
    ResourceesComponent,
    ResourceComponent,
    ResourceListComponent,
   CourseComponent,
    CoursesComponent,
    CourseListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ResourceService, CourseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
