import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resourcees',
  templateUrl: './resourcees.component.html',
  styleUrls: ['./resourcees.component.css']
})
export class ResourceesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
